import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def recommend_resolution(df, user_input):
    selected_columns = ['Issue Description','Resolution']
    data = df[selected_columns]
    data.dropna(inplace=True)
    training_data = data

    # Step 2: Feature extraction
    tfidf_vectorizer = TfidfVectorizer()
    incident_vectors = tfidf_vectorizer.fit_transform(training_data['Issue Description'])

    # Step 3: Similarity calculation
    similarity_matrix = cosine_similarity(incident_vectors)
    user_input_vector = tfidf_vectorizer.transform([user_input])
    similarity_scores = cosine_similarity(user_input_vector, incident_vectors).flatten()

    # Calculate weighted similarity scores based on resolution theme frequencies
    resolution_themes = training_data['Resolution'].unique()
    theme_frequencies = training_data['Resolution'].value_counts().to_dict()
    weighted_similarity_scores = np.zeros(similarity_scores.shape)

    for i, score in enumerate(similarity_scores):
        incident_theme = training_data.iloc[i]['Resolution']
        weighted_score = score / theme_frequencies[incident_theme]
        weighted_similarity_scores[i] = weighted_score

    top_k_indices = weighted_similarity_scores.argsort()[:-6:-1]  # Select top 5 similar incidents
    recommendations = training_data.iloc[top_k_indices]['Resolution'].values.tolist()
    
    return recommendations