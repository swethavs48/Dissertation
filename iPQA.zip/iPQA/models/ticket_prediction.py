import pandas as pd
import joblib
import matplotlib
matplotlib.use('Agg')  # Use a non-interactive backend
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from pathlib import Path
import threading

def predict_no_of_tickets_xb(date_str, model):
    input_date = pd.to_datetime(date_str)
    input_day_of_year = input_date.timetuple().tm_yday
    input_day_of_week = input_date.weekday()
    input_month = input_date.month
    input_year = input_date.year

    input_features = pd.DataFrame({
        'DayOfYear': [input_day_of_year],
        'DayOfWeek': [input_day_of_week],
        'Month': [input_month],
        'Year': [input_year]
    })

    model_xb = joblib.load(model)
    prediction = model_xb.predict(input_features)
    predicted_tickets = prediction[0]

    dates = pd.date_range(start=input_date, periods=14, freq='D')
    input_dates = pd.DataFrame({
        'DayOfYear': dates.dayofyear,
        'DayOfWeek': dates.weekday,
        'Month': dates.month,
        'Year': dates.year
    })
    predictions = model_xb.predict(input_dates)

    fig, ax = plt.subplots()
    ax.plot(dates, predictions)
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
    ax.xaxis.set_major_locator(mdates.DayLocator())
    fig.autofmt_xdate()
    ax.set_xlabel('Date')
    ax.set_ylabel('Number of Tickets')
    ax.set_title('Predicted Number of Tickets for the Next Two Weeks')
    ax.grid(True)

    graph_filename = "static/graph.png"
    fig.savefig(graph_filename)
    return round(predicted_tickets), graph_filename
